package com.example.lorena.todolist

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.ViewModelProviders
import android.arch.core.util.Function
import android.arch.lifecycle.Observer
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import android.os.Bundle
import org.jetbrains.anko.selector
import com.example.lorena.todolist.model.*
import com.example.lorena.todolist.store.Renderer
import com.example.lorena.todolist.store.StoreTarefas



class MainActivity : AppCompatActivity(), Renderer<TarefasModelo> {
    private lateinit var store: StoreTarefas

    override fun render(model: LiveData<TarefasModelo>) {
        model.observe(this, Observer { newState ->
            listView.adapter = TarefaAdapter(this, newState?.tarefa ?: listOf())
        })

        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = ViewModelProviders.of(this).get(StoreTarefas::class.java)
        store.subscribe(this, mapStateToProps)

       addButton.setOnClickListener {
            store.dispatch(AddTarefa(editText.text.toString()))
            editText.text = null
        }
        floatingActionButton.setOnClickListener { openDialog() }

        listView.adapter = TarefaAdapter(this, listOf())
        listView.setOnItemClickListener({ _, _, _, id ->
            store.dispatch(EditarTarefa(id))
        })

        listView.setOnItemLongClickListener { _, _, _, id ->
            store.dispatch(RemoverTarefa(id))
            true
        }
    }

    private fun openDialog() {
        val options = resources.getStringArray(R.array.filter_options).asList()
        selector(getString(R.string.filter_title), options, { _, i ->
            val visible = when(i) {
                1 -> Visibility.Ativos()
                2 -> Visibility.Completos()
                else -> Visibility.Todos()
            }
            store.dispatch(DeixarVisivel(visible))
        })
    
    }

    private val mapStateToProps = Function<TarefasModelo, TarefasModelo>{
        val keep: (Tarefas) -> Boolean = when(it.visibility) {

            is Visibility.Todos -> { _ -> true}
            is Visibility.Ativos -> {t: Tarefas -> !t.status}
            is Visibility.Completos -> {t: Tarefas -> t.status}
        }

        return@Function it.copy(tarefa = it.tarefa.filter { keep(it) })

    }

}

