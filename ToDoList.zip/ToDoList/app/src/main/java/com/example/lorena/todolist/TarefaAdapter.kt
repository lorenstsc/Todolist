package com.example.lorena.todolist

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.todo_item.view.*
import com.example.lorena.todolist.model.Tarefas

class TarefaAdapter(context: Context, val tarefas: List<Tarefas>) : ArrayAdapter<Tarefas>(context, 0,tarefas) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.todo_item, parent, false)

        view.textView.text = tarefas[position].text
        view.checkBox.isChecked = tarefas[position].status

        return view
    }
    override fun getItemId(position: Int): Long = tarefas[position].id
}