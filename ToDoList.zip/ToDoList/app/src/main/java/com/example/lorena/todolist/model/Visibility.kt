package com.example.lorena.todolist.model

sealed class Action

var counter = 0L
//Ações
data class AddTarefa(val text: String, val id: Long = counter++): Action()
data class EditarTarefa(val id: Long) : Action()
data class RemoverTarefa(val id: Long) : Action()
data class DeixarVisivel(val visibility: Visibility) : Action()

//Filtros
sealed class Visibility{
    class Todos: Visibility()
    class Ativos: Visibility()
    class Completos: Visibility()
}