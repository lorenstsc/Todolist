package com.example.lorena.todolist.store

import android.arch.core.util.Function
import com.example.lorena.todolist.model.Action

interface Store<T> {

    //Aplicar actions
    fun dispatch(action: Action)

    //
     fun subscribe(renderer: Renderer<T>, func: Function<T, T> = Function { it })

}