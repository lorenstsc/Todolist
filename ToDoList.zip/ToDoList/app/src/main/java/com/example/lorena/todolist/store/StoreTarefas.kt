package com.example.lorena.todolist.store

import android.arch.core.util.Function
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
//import android.arch.lifecycle.Transformations
import android.arch.lifecycle.ViewModel
import com.example.lorena.todolist.model.*


class StoreTarefas: Store<TarefasModelo>, ViewModel() {
    override fun subscribe(renderer: Renderer<TarefasModelo>, func: Function<TarefasModelo, TarefasModelo>) {
              renderer.render(Transformations.map(state, func))
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private val state: MutableLiveData<TarefasModelo> = MutableLiveData()
    private val initState = TarefasModelo(listOf(), Visibility.Todos())


    override fun dispatch(action: Action) {
        //Mudar o estado de acordo com a ação
        state.value = reduce(state.value, action)
    }

    private fun reduce(state: TarefasModelo?, action: Action): TarefasModelo {
        val newState = state ?: initState

        return when(action) {
            is AddTarefa -> newState.copy(
                    tarefa = newState.tarefa.toMutableList().apply {
                        add(Tarefas(action.text, action.id))
                    }
            )
            is EditarTarefa -> newState.copy(
                    tarefa = newState.tarefa.toMutableList().map {
                        if (it.id == action.id) {
                        it.copy(status = !it.status)
                    } else it }
                            as MutableList<Tarefas>
            )
            is RemoverTarefa -> newState.copy(
                    tarefa = newState.tarefa.filter {
                        it.id != action.id
                    } as MutableList<Tarefas>
            )

            is DeixarVisivel -> newState.copy(
                    visibility = action.visibility
            )

        }
    }

}