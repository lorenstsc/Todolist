package com.example.lorena.todolist.model

data class Tarefas(val text: String, val id: Long, val status: Boolean = false)

