package com.example.lorena.todolist.model

data class TarefasModelo(val tarefa: List<Tarefas>, val visibility: Visibility)
